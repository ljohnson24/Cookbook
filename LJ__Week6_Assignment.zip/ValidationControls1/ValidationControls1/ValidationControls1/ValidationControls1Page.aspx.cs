﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using ValidationControls1;

public partial class ValidationControls1Page : System.Web.UI.Page
{
    //initalize visitor
    public User user;

    //stores values to represent recentVisitors as cookies
    public Dictionary<int, User> users;

    protected void Page_Load(object sender, EventArgs e)
    {
        user = new ValidationControls1.User();
        users = new Dictionary<int, User>();
    }

    protected void ServerValidate(object sender, ServerValidateEventArgs args)
    {
        int num = Int32.Parse(args.Value);
        if ((num % 2) == 0)
            args.IsValid = true;
        else
            args.IsValid = false;
    }

    protected void button1_Click(object sender, EventArgs e)
    {
        // display appropriate message and hyperlinks
        responseLabel.Visible = true;
        homeLink.Visible = true;
        verifyLink.Visible = true;

        //hide initial forms and buttons
        button1.Visible = false;
        id.Visible = false;
        text1.Visible = false;
        firstname.Visible = false;
        text2.Visible = false;
        lastname.Visible = false;
        text3.Visible = false;
        dob.Visible = false;
        text4.Visible = false;
        label1.Visible = false;
        timeout.Visible = false;
        user.Id = Convert.ToInt32(text1.Text);
        user.firstname = text2.Text;
        user.lastname = text3.Text;
        user.dateofbirth = text4.Text;
        users.Add(user.Id, user);
        //check if all data was entered
        if (user != null)
        {
            //check whether a session exist already
            if (Session["Users"] != null)
            {
                //updates the current session with old and new users
                Dictionary<int,User> temp = (Dictionary<int, User>)Session["Users"];
                //take new user and add it to the temp user
                temp.Add(user.Id, user);
                Session.Add("Users", temp);
            }
            else
            {
                // add name and value pair to session
                Session.Add("Users", users);
            }
           
            
        }
        else
        {
            // inform the user that no selection was made
            responseLabel.Text += "You did not complete form.";
        }
        //display session id
        label1.Text = "Your unique session ID is: " + Session.SessionID + ".";
        label1.Visible = true;

        //display amount of time before seeion times out
        timeout.Text = "Timeout: " + Session.Timeout + " minutes.";
        timeout.Visible = true;
    }

    
}

