﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ValidationControls1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        Dictionary<int, User> users;
        
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            
            int userid = Convert.ToInt32(TextBox1.Text);
            if (Session.Count > 0)
            {
                if (Session["Users"] != null)
                {
                    users = (Dictionary<int,User>)Session["Users"];
                    //check whether the user is a revisitor
                    if (users.ContainsKey(userid))
                    {
                        Label1.Text = "Welcome back " + users[userid].lastname+", "+users[userid].firstname+"!"+ "[UserID: " + 
                        users[userid].Id.ToString()+ ", Date of Birth: " + users[userid].dateofbirth.ToString()+"]";
                        TextBox1.Visible = false;
                        Button1.Visible = false;
                    }
                    else
                    {
                        Label1.Text = "Either you are not a returning user or your session has expired";
                        //responseLabel.Visible = true;
                        homeLink.Visible = true;
                        Button1.Visible = false;
                        TextBox1.Visible = false;

                    }
                }
                
            }
           
            
            
        }
    }
}