﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ValidationControls1
{
    public class User
    {
        public int Id { set; get; }
        public string firstname { set; get; }
        public string lastname { set; get; }
        public string dateofbirth { set; get; }

        public User() { }
        public User(int id, string firstname, string lastname, string dateofbirth)
        {
            this.Id = id;
            this.firstname = firstname;
            this.lastname = lastname;
            this.dateofbirth = dateofbirth;
        }
    }
}