﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Recommendations_Cookies : System.Web.UI.Page
{
    protected void Page_Init(object sender, EventArgs e)
    {
        // retrieve client's cookies
        HttpCookieCollection cookies = Request.Cookies;

        // if there are cookies, list the appropriate books and ISBNs
        if (cookies.Count > 0)
        {
            for (int i = 0; i < cookies.Count; i++)
            {
                booksListBox.Items.Clear();
                booksListBox.Items.Add("How to Program " + 
                                       cookies[i].Name + ". ISBN: " + 
                                       cookies[i].Value);
            }
        }
        else
        {
            // if there are no cookies, then no language was chosen, so
	        // display appropriate message and clear and hide booksListBox
	        recommendationsLabel.Text = "No Recommendations";
	        booksListBox.Visible = false;
	
	        // modify languageLink because no language was selected
	        languageLink.Text = "Click here to choose a language.";
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {

    }
}
