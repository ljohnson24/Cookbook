﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class numberbox : System.Web.UI.UserControl
{
    public int pNum
    {
        get
        {
            return Convert.ToInt32(txtNum1.Text);
        }
        set
        {
            txtNum1.Text = Convert.ToString(value);
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        // Put user code to initialize the page here
        if (!Page.IsPostBack)
            txtNum1.Text = "0";
    }
}
