﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Configuration;
using System.Configuration;

public partial class AjaxExample : System.Web.UI.Page 
{
    // Page_Load event handler executes when the page is loaded
    protected void Page_Load( object sender, EventArgs e )
    {
        // if this is not the first time the page is loading
        // (i.e., the user has already submitted form data)
        if ( IsPostBack )
        {
            Validate(); // validate the form
            
            // if the form is valid
            if ( IsValid )
            {
                Trace.Write("Page is validated.");

                // retrieve the values submitted by the user
                string first = firstNameTextBox.Text;
                string last = lastNameTextBox.Text;
                string email = emailTextBox.Text;
                string phone = phoneTextBox.Text;
                
                // create a table indicating the submitted values
                outputLabel.Text +=
                        "<br />We received the following information:" +
                        "<table style=\"background-color: yellow\">" +
                        "<tr><td>First Name:</td><td>" + first + "</td></tr>" +
                        "<tr><td>Last Name:</td><td>" + last + "</td></tr>" +
                        "<tr><td>E-mail address:</td><td>" + email +
                        "</td></tr>" +
                        "<tr><td>Phone number:</td><td>" + phone + "</td></tr>" +
                        "</table>";
                
                outputLabel.Visible = true; // display the output message;

                // **************************************
                // Configuration - User-defined Settings
                // **************************************
                string customSetting = System.Configuration.ConfigurationManager.AppSettings.Get("customsetting1");
                if (customSetting != null)
                {
                    outputLabel.Text += "customsetting1 application string = " + customSetting;
                    Trace.Warn("customsetting1 application string = " + customSetting);
                }
                else
                    outputLabel.Text += "No customsetting1 application string";
         } // end if
      } // end if
   }

    protected void submitButton_Click(object sender, EventArgs e)
    {

    } // end method Page_Load
}
