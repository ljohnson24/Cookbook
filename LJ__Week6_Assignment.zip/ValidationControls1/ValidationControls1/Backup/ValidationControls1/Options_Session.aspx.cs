﻿// Options.aspx.cs
// Processes user's selection of a programming language by displaying
// links and writing a cookie to the user's machine.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Options_Sessions : System.Web.UI.Page
{
    //stores values to represent books as cookies
    private Dictionary<string, string> books =
                                new Dictionary<string, string>();

    // initializes the dictionary when the page inits
    protected void Page_Init(object sender, EventArgs e)
    {
        books.Add("Visual Basic 2008", "0-13-606305-X");
        books.Add("Visual C# 2008", "0-13-605322-X");
        books.Add("C", "0-13-240416-8");
        books.Add("C++", "0-13-615250-3");
        books.Add("Java", "0-13-222220-5");
    } // end Page_Init

    // hide and display links to make additional selections or view
    // recommendations, and write a cookie to record the user's selection
    // when the form is submitted
    protected void submitButton_Click(object sender, EventArgs e)
    {
        // display appropriate message and hyperlinks
        responseLabel.Visible = true;
        idLabel.Visible = true;
        timeoutLabel.Visible = true;
        languageLink.Visible = true;
        recommendationsLink.Visible = true;

        // hide controls for selecting a language
        promptLabel.Visible = false;
        languageList.Visible = false;
        submitButton.Visible = false;

        if (languageList.SelectedItem != null)
        {
            // get value of user's selection
            string language = languageList.SelectedItem.Value;

            // get ISBN for given language
            string ISBN = books[language];

            // add name/value pair to Session
            Session.Add(language, ISBN);

            // display user's selection
            responseLabel.Text += "You selected " + language + ".";
        }
        else
        {
            // inform the user that no selection was made
            responseLabel.Text += "You did not make a selection.";
        }

        // display session ID.
        idLabel.Text = "Your unique session ID is: " + 
                        Session.SessionID + ".";

        // display amount of tiem before session times out
        timeoutLabel.Text = "Timeou: " + Session.Timeout + " minutes.";

    }
}
