﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Recommendations_Sessions : System.Web.UI.Page
{
    protected void Page_Init(object sender, EventArgs e)
    {
        // if there are Session items, list the appropriate books and ISBNs
        if (Session.Count > 0)
        {
            // use current key to display one of the session’s           
	        // name/value pairs
            foreach (string keyname in Session.Keys)
            {
                booksListBox.Items.Clear();
                booksListBox.Items.Add("How to Program " +
                                       keyname + ". ISBN: " +
                                       Session[keyname]);
            }
        }
        else
        {
            // if there are no items, then no language was chosen, so
            // display appropriate message and clear and hide booksListBox
            recommendationsLabel.Text = "No Recommendations";
            booksListBox.Visible = false;

            // modify languageLink because no language was selected
            languageLink.Text = "Click here to choose a language.";
        }
    }
}
