﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, System.EventArgs e)
    {
        //check Page.IsValid
        if (Page.IsValid)
            lblSum.Text = Convert.ToString(Convert.ToInt32(txtNum1.Text) + Convert.ToInt32(txtNum2.Text));
    }
    protected void txtNum1_TextChanged(object sender, EventArgs e)
    {

    }
}
