﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Comp425_Assignment2
{
    public class Metal
    {
        private bool electricalConductive;
        private bool thermalConductive;
        private bool electricalInsulation;
        private bool thermalInsulation;

        public Metal()
        {
            this.electricalConductive = true;
            this.thermalConductive = true;
            this.electricalInsulation = false;
            this.thermalInsulation = false;
        }

        public bool getElectricalConductive() { return this.electricalConductive; }
        public bool getThermalConductive() { return this.thermalConductive; }
        public bool getThermalInsulation() { return this.thermalInsulation; }
        public bool getElectricalInsulation() { return this.electricalInsulation ; }
    }
}
