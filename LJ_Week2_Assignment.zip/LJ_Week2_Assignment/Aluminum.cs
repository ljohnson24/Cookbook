﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Comp425_Assignment2
{
    class Aluminum:Metal
    {
        private bool meltsAtLowTemp;
        private bool soft;

        public Aluminum() { this.meltsAtLowTemp = true;this.soft = true; }
        public bool getSoftness() { return soft; }
        public bool getMelting() { return meltsAtLowTemp; }
    }
}
