﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Comp425_Assignment2
{
    class Program
    {
        static void Main(string[] args)
        {
            Aluminum alum = new Aluminum();
            Console.WriteLine("Aluminum: ");
            Console.WriteLine("Electrial conductivity: " +alum.getElectricalConductive());
            Console.WriteLine("Thermal conductivity: " + alum.getThermalConductive());
            Console.WriteLine("Thermal conductivity: " + alum.getThermalConductive());
            Console.WriteLine("Electrial conductivity: " + alum.getElectricalConductive());
            Console.WriteLine();
            Console.WriteLine("Soft: " + alum.getSoftness());
            Console.WriteLine("Melt at high temps: " + alum.getMelting());

            Console.ReadLine();

        }
    }
}
